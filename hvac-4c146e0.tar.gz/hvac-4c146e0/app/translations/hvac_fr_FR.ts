<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>HVAC</name>
    <message>
        <location filename="../HVAC.qml" line="66"/>
        <source>FAN SPEED</source>
        <translation>Vitesse de ventilation</translation>
    </message>
    <message>
        <location filename="../HVAC.qml" line="98"/>
        <source>A/C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../HVAC.qml" line="111"/>
        <source>AUTO</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>HeatDegree</name>
    <message>
        <location filename="../HeatDegree.qml" line="31"/>
        <source>LO</source>
        <translation>BAS</translation>
    </message>
    <message>
        <location filename="../HeatDegree.qml" line="33"/>
        <source>%1°</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../HeatDegree.qml" line="35"/>
        <source>HI</source>
        <translation>HAU</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../main.cpp" line="44"/>
        <source>port for binding</source>
        <translation>Port du binding</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="45"/>
        <source>secret for binding</source>
        <translation>Token de sécurité du binding</translation>
    </message>
</context>
</TS>
