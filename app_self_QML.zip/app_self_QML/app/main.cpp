#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQmlProperty>
#include <QUrlQuery>
#include <QDebug>

class Backend : public QObject {
  Q_OBJECT
  Q_PROPERTY(QString text READ text WRITE setText NOTIFY textChanged)   //Property makes "backend.text" in QML useable
  Q_PROPERTY(QString recvtxt READ recvtxt WRITE setRecvtxt NOTIFY recvtxtChanged)  //self-test
public:
  QString text() const { return mText; }
  QString recvtxt() const {return mRecvTxt;}    //self-text

  void setText(const QString &text) {
            if (text == mText) return;
            mText = text;
            emit textChanged(mText);
  }

  void setRecvtxt(const QString &recvtxt) {     //self-text
            if(recvtxt == mRecvTxt) return;
            mRecvTxt = recvtxt;
            emit recvtxtChanged(mRecvTxt);
  }


signals:
  void textChanged(const QString &text);
  void recvtxtChanged(const QString &recvtxt);  //self-test

private:
  QString mText;
  QString mRecvTxt;     //self-test
};

int main(int argc, char *argv[]) {
  QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

  QGuiApplication app(argc, argv);
  app.setApplicationName(QStringLiteral("MoTalk"));
  app.setApplicationVersion(QStringLiteral("0.1"));

  Backend backend;
  QQmlApplicationEngine engine;

  //set up conection to websocket-server
  int port = 1234;
  QString secret = "123456";
  QUrl ws_binding;
  ws_binding.setScheme(QStringLiteral("ws"));   //set scheme like http,ws,ftp etc.
  ws_binding.setHost(QStringLiteral("localhost"));
  ws_binding.setPort(port);
  ws_binding.setPath(QStringLiteral("/api"));   //path comes after the authority of the URL (e.g: .com) but before query string

  QUrlQuery ws_query;
  ws_query.addQueryItem(QStringLiteral("token"),secret);    //appends the pair 'token=secret' to the end of the query string
  ws_binding.setQuery(ws_query);        //appends query to the end of URL ws_binding

  engine.rootContext()->setContextProperty(QStringLiteral("ws_binding"),ws_binding);

  // backend should be available to all QML component instances instantiated by the engine
  //Set the value (backend object) of the name ("backend") property on this context.
  engine.rootContext()->setContextProperty("backend", &backend);
  engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
  if (engine.rootObjects().isEmpty())   //Returns a list of all root objects instantiated by engine.load() or a constructor
    return -1;

  //QObject::connect(const QObject *sender, PointerToMemberFunction signal, Functor functor)
  //sender = backend, signal=textChanged, functor = text-output
  QObject::connect(&backend, &Backend::textChanged,[](const QString &text) { qDebug() << "output of main.cpp: " << text; });
  QObject::connect(&backend, &Backend::recvtxtChanged,[](const QString &recvtxt){qDebug() << "recvtxt speaking: " << recvtxt;});

  return app.exec();
}

#include "main.moc"

