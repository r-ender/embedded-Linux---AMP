#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QObject>
#include <QCoreApplication>
#include <QKeyEvent>
#include <QQuickItem>


int main(int argc, char* argv[])
{
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    QQmlContext* ctx = engine.rootContext();
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    return app.exec();
}



/*
class KeyEmitter : public QObject
{
    Q_OBJECT

public:
    KeyEmitter();
    ~KeyEmitter();

public slots:
    void emitKey(Qt::Key key);
};

KeyEmitter::KeyEmitter()
{
}

KeyEmitter::~KeyEmitter()
{
}

void KeyEmitter::emitKey(Qt::Key key)
{
    QQuickItem* receiver = qobject_cast<QQuickItem*>(QGuiApplication::focusObject());
    if(!receiver) {
        return;
    }
    QKeyEvent pressEvent = QKeyEvent(QEvent::KeyPress, key, Qt::NoModifier, QKeySequence(key).toString());
    QKeyEvent releaseEvent = QKeyEvent(QEvent::KeyRelease, key, Qt::NoModifier);
    QCoreApplication::sendEvent(receiver, &pressEvent);
    QCoreApplication::sendEvent(receiver, &releaseEvent);
}

int main(int argc, char* argv[])
{
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    KeyEmitter keyEmitter;
    QQmlContext* ctx = engine.rootContext();
    ctx->setContextProperty("keyEmitter", &keyEmitter);
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    return app.exec();
}
 */
//#include "main.moc"
